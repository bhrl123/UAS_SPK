# Tugas UAS SPK
Nama : Muhammad Bahrul Alam <br>
NIM : 201011400606 <br>
Kelas : 07-TPLP-013<br>

## Install requirements
```pip install -r requirements.txt```

## Run the app
Untuk menjalankan:
```python main.py```

## Usage
Install postman:
[`Postman`](https://www.postman.com/downloads/)

