# Tugas spk_model
Nama : Muhammad Bahrul Alam <br>
NIM : 201011400606 <br>
Kelas : 07-TPLP-013<br>
